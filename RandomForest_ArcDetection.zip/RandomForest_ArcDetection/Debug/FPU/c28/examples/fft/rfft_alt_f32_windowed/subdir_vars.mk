################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/dsp_rfft_windowed.c \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/golden.c \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/input.c 

C_DEPS += \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/dsp_rfft_windowed.d \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/golden.d \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/input.d 

OBJS += \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/dsp_rfft_windowed.obj \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/golden.obj \
./FPU/c28/examples/fft/rfft_alt_f32_windowed/input.obj 

OBJS__QUOTED += \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\dsp_rfft_windowed.obj" \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\golden.obj" \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\input.obj" 

C_DEPS__QUOTED += \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\dsp_rfft_windowed.d" \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\golden.d" \
"FPU\c28\examples\fft\rfft_alt_f32_windowed\input.d" 

C_SRCS__QUOTED += \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/dsp_rfft_windowed.c" \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/golden.c" \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/rfft_alt_f32_windowed/input.c" 


