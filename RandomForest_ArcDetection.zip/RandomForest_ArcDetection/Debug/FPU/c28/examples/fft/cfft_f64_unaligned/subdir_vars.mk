################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/dsp_cfft_unaligned.c \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/golden.c \
C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/input.c 

C_DEPS += \
./FPU/c28/examples/fft/cfft_f64_unaligned/dsp_cfft_unaligned.d \
./FPU/c28/examples/fft/cfft_f64_unaligned/golden.d \
./FPU/c28/examples/fft/cfft_f64_unaligned/input.d 

OBJS += \
./FPU/c28/examples/fft/cfft_f64_unaligned/dsp_cfft_unaligned.obj \
./FPU/c28/examples/fft/cfft_f64_unaligned/golden.obj \
./FPU/c28/examples/fft/cfft_f64_unaligned/input.obj 

OBJS__QUOTED += \
"FPU\c28\examples\fft\cfft_f64_unaligned\dsp_cfft_unaligned.obj" \
"FPU\c28\examples\fft\cfft_f64_unaligned\golden.obj" \
"FPU\c28\examples\fft\cfft_f64_unaligned\input.obj" 

C_DEPS__QUOTED += \
"FPU\c28\examples\fft\cfft_f64_unaligned\dsp_cfft_unaligned.d" \
"FPU\c28\examples\fft\cfft_f64_unaligned\golden.d" \
"FPU\c28\examples\fft\cfft_f64_unaligned\input.d" 

C_SRCS__QUOTED += \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/dsp_cfft_unaligned.c" \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/golden.c" \
"C:/ti/C2000Ware_26_01_00_00/libraries/dsp/FPU/c28/examples/fft/cfft_f64_unaligned/input.c" 


