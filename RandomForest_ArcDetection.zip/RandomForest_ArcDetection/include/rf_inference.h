

    uint16_t arc_fault_votes = 0;

    // ----------------------------------------
    // TREE 1
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 2
    // ----------------------------------------
        if (feat_array[2] <= 0.393407f) {
            if (feat_array[2] <= 0.388553f) {
                if (feat_array[2] <= 0.353759f) {
                    if (feat_array[2] <= 0.265119f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[1] <= 0.323113f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.398508f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.389476f) {
                    arc_fault_votes += 1;
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[2] <= 0.397500f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[1] <= 0.279801f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.370244f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 3
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[1] <= 0.200453f) {
                if (feat_array[1] <= 0.171672f) {
                    if (feat_array[0] <= 0.413600f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.394734f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.419066f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.396657f) {
                if (feat_array[1] <= 0.277776f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369593f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 4
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.277776f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 5
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.287623f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 6
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[1] <= 0.200453f) {
                if (feat_array[1] <= 0.173686f) {
                    if (feat_array[1] <= 0.161593f) {
                        if (feat_array[1] <= 0.154797f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            if (feat_array[2] <= 0.384218f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    } else {
                        if (feat_array[1] <= 0.161612f) {
                            arc_fault_votes += 1;
                        } else {
                            if (feat_array[0] <= 0.408385f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                } else {
                    if (feat_array[2] <= 0.395591f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.252627f) {
                    if (feat_array[0] <= 0.399503f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.387422f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 7
    // ----------------------------------------
        if (feat_array[1] <= 0.259704f) {
            if (feat_array[2] <= 0.403307f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399284f) {
                if (feat_array[1] <= 0.277820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.405708f) {
                    if (feat_array[1] <= 0.274075f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 8
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 9
    // ----------------------------------------
        if (feat_array[2] <= 0.399836f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 10
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 11
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 12
    // ----------------------------------------
        if (feat_array[2] <= 0.393407f) {
            if (feat_array[1] <= 0.276146f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.371442f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 13
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.398513f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.373530f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 14
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.382304f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[0] <= 0.380239f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 15
    // ----------------------------------------
        if (feat_array[1] <= 0.264485f) {
            if (feat_array[1] <= 0.201788f) {
                if (feat_array[0] <= 0.409967f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.252378f) {
                    if (feat_array[1] <= 0.225150f) {
                        if (feat_array[2] <= 0.412726f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[2] <= 0.413845f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[1] <= 0.254267f) {
                        if (feat_array[1] <= 0.253974f) {
                            if (feat_array[0] <= 0.418184f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            if (feat_array[0] <= 0.419969f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    } else {
                        if (feat_array[2] <= 0.422389f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[2] <= 0.415284f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.409521f) {
                    if (feat_array[1] <= 0.274935f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 16
    // ----------------------------------------
        if (feat_array[1] <= 0.262394f) {
            if (feat_array[2] <= 0.406462f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372405f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 17
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 18
    // ----------------------------------------
        if (feat_array[0] <= 0.373115f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 19
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372724f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 20
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[2] <= 0.374681f) {
                if (feat_array[1] <= 0.293770f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.398122f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.274569f) {
                if (feat_array[2] <= 0.411452f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 21
    // ----------------------------------------
        if (feat_array[1] <= 0.262268f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400938f) {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369667f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 22
    // ----------------------------------------
        if (feat_array[0] <= 0.370563f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 23
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.405373f) {
                    if (feat_array[1] <= 0.273659f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 24
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[0] <= 0.381946f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 25
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 26
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 27
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399836f) {
                if (feat_array[0] <= 0.407734f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.370170f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 28
    // ----------------------------------------
        if (feat_array[1] <= 0.257582f) {
            if (feat_array[1] <= 0.203314f) {
                if (feat_array[0] <= 0.405833f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.221247f) {
                    if (feat_array[1] <= 0.217565f) {
                        if (feat_array[1] <= 0.217418f) {
                            if (feat_array[1] <= 0.203586f) {
                                if (feat_array[2] <= 0.401679f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            } else {
                                if (feat_array[1] <= 0.217139f) {
                                    if (feat_array[1] <= 0.209737f) {
                                        if (feat_array[1] <= 0.209550f) {
                                            // arc_fault_votes += 0; (Normal Vote)
                                        } else {
                                            arc_fault_votes += 1;
                                        }
                                    } else {
                                        if (feat_array[2] <= 0.424873f) {
                                            // arc_fault_votes += 0; (Normal Vote)
                                        } else {
                                            arc_fault_votes += 1;
                                        }
                                    }
                                } else {
                                    if (feat_array[2] <= 0.439098f) {
                                        // arc_fault_votes += 0; (Normal Vote)
                                    } else {
                                        arc_fault_votes += 1;
                                    }
                                }
                            }
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[2] <= 0.407734f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.385753f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[2] <= 0.400938f) {
                if (feat_array[1] <= 0.277820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 29
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 30
    // ----------------------------------------
        if (feat_array[1] <= 0.259389f) {
            if (feat_array[1] <= 0.189327f) {
                if (feat_array[1] <= 0.171672f) {
                    if (feat_array[1] <= 0.163930f) {
                        if (feat_array[2] <= 0.384218f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[1] <= 0.163932f) {
                            arc_fault_votes += 1;
                        } else {
                            if (feat_array[0] <= 0.408385f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                } else {
                    if (feat_array[1] <= 0.171710f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.181068f) {
                            if (feat_array[0] <= 0.412019f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            if (feat_array[0] <= 0.411478f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.424018f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 31
    // ----------------------------------------
        if (feat_array[1] <= 0.261288f) {
            if (feat_array[0] <= 0.385313f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.401050f) {
                if (feat_array[1] <= 0.283650f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 32
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409807f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[1] <= 0.284065f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 33
    // ----------------------------------------
        if (feat_array[0] <= 0.370602f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 34
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 35
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 36
    // ----------------------------------------
        if (feat_array[0] <= 0.369986f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 37
    // ----------------------------------------
        if (feat_array[0] <= 0.369986f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 38
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[0] <= 0.385401f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372826f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 39
    // ----------------------------------------
        if (feat_array[1] <= 0.263085f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.274118f) {
                    if (feat_array[0] <= 0.380632f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 40
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.396657f) {
                if (feat_array[0] <= 0.398117f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369667f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 41
    // ----------------------------------------
        if (feat_array[0] <= 0.373217f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 42
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[2] <= 0.353759f) {
                    if (feat_array[2] <= 0.265116f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[2] <= 0.265143f) {
                            arc_fault_votes += 1;
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    }
                } else {
                    if (feat_array[2] <= 0.353797f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.473338f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.389476f) {
                    if (feat_array[1] <= 0.274438f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            }
        } else {
            if (feat_array[2] <= 0.409780f) {
                if (feat_array[2] <= 0.408648f) {
                    if (feat_array[2] <= 0.405708f) {
                        if (feat_array[0] <= 0.388370f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 43
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 44
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[1] <= 0.295444f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274619f) {
                if (feat_array[2] <= 0.411312f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 45
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.382304f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.380239f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 46
    // ----------------------------------------
        if (feat_array[1] <= 0.262832f) {
            if (feat_array[1] <= 0.189185f) {
                if (feat_array[2] <= 0.391152f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[2] <= 0.419439f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 47
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[1] <= 0.201801f) {
                if (feat_array[1] <= 0.171672f) {
                    if (feat_array[2] <= 0.385008f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.410562f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.271690f) {
                    if (feat_array[1] <= 0.267375f) {
                        if (feat_array[1] <= 0.267278f) {
                            if (feat_array[1] <= 0.266455f) {
                                if (feat_array[1] <= 0.266331f) {
                                    if (feat_array[2] <= 0.410363f) {
                                        // arc_fault_votes += 0; (Normal Vote)
                                    } else {
                                        arc_fault_votes += 1;
                                    }
                                } else {
                                    // arc_fault_votes += 0; (Normal Vote)
                                }
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.411739f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 48
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 49
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 50
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.382304f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399110f) {
                if (feat_array[0] <= 0.407734f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.272822f) {
                    if (feat_array[2] <= 0.409514f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 51
    // ----------------------------------------
        if (feat_array[1] <= 0.264626f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.386961f) {
                if (feat_array[0] <= 0.397083f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.274552f) {
                    if (feat_array[2] <= 0.417082f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 52
    // ----------------------------------------
        if (feat_array[1] <= 0.264610f) {
            if (feat_array[1] <= 0.201115f) {
                if (feat_array[2] <= 0.377861f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.413414f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.267375f) {
                if (feat_array[1] <= 0.266321f) {
                    if (feat_array[1] <= 0.265225f) {
                        if (feat_array[0] <= 0.413793f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.266557f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[2] <= 0.436291f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.373828f) {
                    if (feat_array[2] <= 0.371546f) {
                        arc_fault_votes += 1;
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    if (feat_array[0] <= 0.370170f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        }

    // ----------------------------------------
    // TREE 53
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 54
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 55
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[1] <= 0.287623f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 56
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[2] <= 0.403749f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.264485f) {
                if (feat_array[0] <= 0.386187f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.404355f) {
                    if (feat_array[1] <= 0.273548f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 57
    // ----------------------------------------
        if (feat_array[0] <= 0.370563f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 58
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 59
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 60
    // ----------------------------------------
        if (feat_array[1] <= 0.262316f) {
            if (feat_array[2] <= 0.403749f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 61
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[0] <= 0.388081f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370563f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 62
    // ----------------------------------------
        if (feat_array[0] <= 0.370563f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 63
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409780f) {
                if (feat_array[1] <= 0.274935f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 64
    // ----------------------------------------
        if (feat_array[2] <= 0.399836f) {
            if (feat_array[1] <= 0.302071f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 65
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 66
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 67
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[2] <= 0.402914f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.266455f) {
                if (feat_array[0] <= 0.398499f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.274509f) {
                    if (feat_array[1] <= 0.274379f) {
                        if (feat_array[0] <= 0.380632f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 68
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 69
    // ----------------------------------------
        if (feat_array[1] <= 0.260281f) {
            if (feat_array[0] <= 0.385313f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[2] <= 0.375875f) {
                    if (feat_array[2] <= 0.371546f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.388021f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.381256f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.405884f) {
                    if (feat_array[0] <= 0.381711f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 70
    // ----------------------------------------
        if (feat_array[1] <= 0.261385f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.398318f) {
                if (feat_array[2] <= 0.378878f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[2] <= 0.386316f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[0] <= 0.382264f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[0] <= 0.369281f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 71
    // ----------------------------------------
        if (feat_array[0] <= 0.370563f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 72
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 73
    // ----------------------------------------
        if (feat_array[1] <= 0.262530f) {
            if (feat_array[1] <= 0.201700f) {
                if (feat_array[2] <= 0.377923f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.416970f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.265409f) {
                if (feat_array[0] <= 0.419846f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.272783f) {
                    if (feat_array[1] <= 0.271690f) {
                        if (feat_array[2] <= 0.405866f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[0] <= 0.414249f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 74
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 75
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 76
    // ----------------------------------------
        if (feat_array[1] <= 0.261385f) {
            if (feat_array[0] <= 0.393820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[2] <= 0.375875f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[2] <= 0.384061f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[0] <= 0.381256f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.405884f) {
                    if (feat_array[1] <= 0.274075f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 77
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 78
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 79
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[2] <= 0.387214f) {
                if (feat_array[2] <= 0.370092f) {
                    if (feat_array[0] <= 0.398068f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.472529f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 80
    // ----------------------------------------
        if (feat_array[1] <= 0.264693f) {
            if (feat_array[2] <= 0.407072f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[2] <= 0.413083f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 81
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.382304f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[2] <= 0.411312f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 82
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372405f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 83
    // ----------------------------------------
        if (feat_array[0] <= 0.373217f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 84
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 85
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[0] <= 0.391121f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.398318f) {
                if (feat_array[1] <= 0.277026f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.372432f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 86
    // ----------------------------------------
        if (feat_array[2] <= 0.393407f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399110f) {
                if (feat_array[0] <= 0.414440f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.274509f) {
                    if (feat_array[2] <= 0.411312f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 87
    // ----------------------------------------
        if (feat_array[1] <= 0.262394f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370563f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 88
    // ----------------------------------------
        if (feat_array[0] <= 0.372865f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 89
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.274293f) {
                    if (feat_array[1] <= 0.271690f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.272822f) {
                            if (feat_array[0] <= 0.414249f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 90
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 91
    // ----------------------------------------
        if (feat_array[1] <= 0.259966f) {
            if (feat_array[2] <= 0.403446f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.267375f) {
                if (feat_array[1] <= 0.265350f) {
                    if (feat_array[0] <= 0.386681f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.397717f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.272121f) {
                    if (feat_array[0] <= 0.393596f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 92
    // ----------------------------------------
        if (feat_array[1] <= 0.263093f) {
            if (feat_array[1] <= 0.203267f) {
                if (feat_array[1] <= 0.179279f) {
                    if (feat_array[2] <= 0.382428f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.179345f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.411122f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.427150f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.392796f) {
                if (feat_array[2] <= 0.390335f) {
                    if (feat_array[0] <= 0.380032f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[1] <= 0.274552f) {
                    if (feat_array[0] <= 0.380313f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 93
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 94
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.368704f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 95
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.388553f) {
                if (feat_array[1] <= 0.306750f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.405708f) {
                    if (feat_array[2] <= 0.405373f) {
                        arc_fault_votes += 1;
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 96
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 97
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[2] <= 0.409514f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 98
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[0] <= 0.388081f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.274293f) {
                    if (feat_array[2] <= 0.409341f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 99
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[1] <= 0.284902f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 100
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 101
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 102
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 103
    // ----------------------------------------
        if (feat_array[0] <= 0.373217f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 104
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[1] <= 0.201783f) {
                if (feat_array[1] <= 0.164913f) {
                    if (feat_array[0] <= 0.406930f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.408385f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.406323f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[1] <= 0.274935f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 105
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[0] <= 0.385401f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 106
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[0] <= 0.398161f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.381256f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 107
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.307545f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[0] <= 0.381711f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 108
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[2] <= 0.411452f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 109
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 110
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[1] <= 0.287667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 111
    // ----------------------------------------
        if (feat_array[1] <= 0.260857f) {
            if (feat_array[0] <= 0.385401f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[2] <= 0.397500f) {
                    if (feat_array[0] <= 0.398122f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[2] <= 0.405884f) {
                    if (feat_array[1] <= 0.274075f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 112
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.382264f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[1] <= 0.274075f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 113
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[2] <= 0.407212f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[2] <= 0.415284f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 114
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[0] <= 0.381711f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 115
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[1] <= 0.197199f) {
                if (feat_array[1] <= 0.175949f) {
                    if (feat_array[0] <= 0.405783f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.374699f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.399284f) {
                if (feat_array[2] <= 0.371546f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[1] <= 0.342976f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.272783f) {
                    if (feat_array[2] <= 0.415284f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 116
    // ----------------------------------------
        if (feat_array[0] <= 0.369937f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 117
    // ----------------------------------------
        if (feat_array[1] <= 0.259389f) {
            if (feat_array[2] <= 0.403307f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399836f) {
                if (feat_array[2] <= 0.376188f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[1] <= 0.277820f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.369667f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 118
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.271690f) {
                    if (feat_array[2] <= 0.407072f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.413083f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 119
    // ----------------------------------------
        if (feat_array[0] <= 0.369876f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 120
    // ----------------------------------------
        if (feat_array[0] <= 0.369876f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 121
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[1] <= 0.201783f) {
                if (feat_array[1] <= 0.171666f) {
                    if (feat_array[2] <= 0.385008f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.398494f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.391121f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.400938f) {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.370244f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 122
    // ----------------------------------------
        if (feat_array[1] <= 0.260953f) {
            if (feat_array[2] <= 0.403749f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370563f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 123
    // ----------------------------------------
        if (feat_array[2] <= 0.395478f) {
            if (feat_array[2] <= 0.388680f) {
                if (feat_array[0] <= 0.398508f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.283466f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.404355f) {
                if (feat_array[1] <= 0.273548f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.372331f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 124
    // ----------------------------------------
        if (feat_array[1] <= 0.262148f) {
            if (feat_array[1] <= 0.201788f) {
                if (feat_array[0] <= 0.405783f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.393820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[1] <= 0.277820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.409521f) {
                    if (feat_array[2] <= 0.408648f) {
                        if (feat_array[1] <= 0.274075f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 125
    // ----------------------------------------
        if (feat_array[0] <= 0.373849f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 126
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 127
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 128
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 129
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 130
    // ----------------------------------------
        if (feat_array[2] <= 0.393271f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 131
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 132
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 133
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.398117f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[0] <= 0.384968f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 134
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 135
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372724f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 136
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.266424f) {
                if (feat_array[1] <= 0.266321f) {
                    if (feat_array[2] <= 0.416424f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[0] <= 0.370170f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 137
    // ----------------------------------------
        if (feat_array[2] <= 0.401608f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[2] <= 0.374681f) {
                    if (feat_array[1] <= 0.289126f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.374760f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[2] <= 0.375875f) {
                            if (feat_array[0] <= 0.545645f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    }
                }
            } else {
                if (feat_array[1] <= 0.274438f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[0] <= 0.385485f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 138
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[1] <= 0.201700f) {
                if (feat_array[1] <= 0.171765f) {
                    if (feat_array[2] <= 0.385501f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.171788f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.409299f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.403749f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.370563f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 139
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 140
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.277776f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.368704f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 141
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 142
    // ----------------------------------------
        if (feat_array[1] <= 0.260990f) {
            if (feat_array[1] <= 0.182794f) {
                if (feat_array[1] <= 0.161586f) {
                    if (feat_array[1] <= 0.154791f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[2] <= 0.384218f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.408330f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.224336f) {
                    if (feat_array[1] <= 0.183182f) {
                        if (feat_array[1] <= 0.183141f) {
                            if (feat_array[0] <= 0.403647f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            if (feat_array[1] <= 0.183147f) {
                                arc_fault_votes += 1;
                            } else {
                                if (feat_array[1] <= 0.183166f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            }
                        }
                    } else {
                        if (feat_array[1] <= 0.201039f) {
                            if (feat_array[1] <= 0.193534f) {
                                if (feat_array[2] <= 0.400442f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            } else {
                                if (feat_array[0] <= 0.420744f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            }
                        } else {
                            if (feat_array[2] <= 0.409905f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                } else {
                    if (feat_array[2] <= 0.409513f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 143
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[1] <= 0.287623f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[0] <= 0.389333f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 144
    // ----------------------------------------
        if (feat_array[1] <= 0.263085f) {
            if (feat_array[2] <= 0.406462f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400938f) {
                if (feat_array[0] <= 0.395794f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.370170f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 145
    // ----------------------------------------
        if (feat_array[1] <= 0.262832f) {
            if (feat_array[1] <= 0.201139f) {
                if (feat_array[1] <= 0.171653f) {
                    if (feat_array[0] <= 0.408875f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.171783f) {
                        if (feat_array[2] <= 0.393227f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[1] <= 0.181107f) {
                            if (feat_array[1] <= 0.173305f) {
                                if (feat_array[1] <= 0.173275f) {
                                    if (feat_array[2] <= 0.405758f) {
                                        // arc_fault_votes += 0; (Normal Vote)
                                    } else {
                                        arc_fault_votes += 1;
                                    }
                                } else {
                                    arc_fault_votes += 1;
                                }
                            } else {
                                if (feat_array[2] <= 0.384866f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            }
                        } else {
                            if (feat_array[2] <= 0.377923f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.406323f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.392796f) {
                if (feat_array[0] <= 0.379693f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.274509f) {
                    if (feat_array[0] <= 0.380239f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 146
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[0] <= 0.393820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 147
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[2] <= 0.396657f) {
                if (feat_array[2] <= 0.369689f) {
                    if (feat_array[0] <= 0.398156f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.302115f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.439927f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.271747f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 148
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.371945f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 149
    // ----------------------------------------
        if (feat_array[2] <= 0.401050f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[1] <= 0.294650f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.277776f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[0] <= 0.382870f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 150
    // ----------------------------------------
        if (feat_array[1] <= 0.261288f) {
            if (feat_array[0] <= 0.385401f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272121f) {
                if (feat_array[1] <= 0.271815f) {
                    if (feat_array[0] <= 0.386681f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[0] <= 0.369593f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 151
    // ----------------------------------------
        if (feat_array[1] <= 0.261918f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.368947f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 152
    // ----------------------------------------
        if (feat_array[0] <= 0.373618f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 153
    // ----------------------------------------
        if (feat_array[1] <= 0.259983f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 154
    // ----------------------------------------
        if (feat_array[2] <= 0.401050f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[1] <= 0.295444f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.381997f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[2] <= 0.411312f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 155
    // ----------------------------------------
        if (feat_array[2] <= 0.398559f) {
            if (feat_array[2] <= 0.393407f) {
                if (feat_array[2] <= 0.388647f) {
                    if (feat_array[0] <= 0.398508f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.381997f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.393849f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[1] <= 0.372114f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 156
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[2] <= 0.388553f) {
                if (feat_array[0] <= 0.398513f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.277776f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[0] <= 0.381711f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 157
    // ----------------------------------------
        if (feat_array[1] <= 0.262316f) {
            if (feat_array[1] <= 0.201039f) {
                if (feat_array[0] <= 0.405592f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.403749f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[0] <= 0.380632f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 158
    // ----------------------------------------
        if (feat_array[1] <= 0.263549f) {
            if (feat_array[2] <= 0.405771f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.396657f) {
                if (feat_array[1] <= 0.287667f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.372432f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 159
    // ----------------------------------------
        if (feat_array[1] <= 0.258859f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 160
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.398156f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[2] <= 0.411452f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 161
    // ----------------------------------------
        if (feat_array[1] <= 0.261288f) {
            if (feat_array[1] <= 0.197199f) {
                if (feat_array[1] <= 0.175979f) {
                    if (feat_array[1] <= 0.154791f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[2] <= 0.387356f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[1] <= 0.176005f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.195387f) {
                            if (feat_array[2] <= 0.374699f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    }
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.370563f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 162
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[1] <= 0.201039f) {
                if (feat_array[0] <= 0.406980f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.390769f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 163
    // ----------------------------------------
        if (feat_array[0] <= 0.369986f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 164
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 165
    // ----------------------------------------
        if (feat_array[0] <= 0.373115f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 166
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 167
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.295400f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 168
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[2] <= 0.388551f) {
                if (feat_array[2] <= 0.369610f) {
                    if (feat_array[0] <= 0.398156f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.397704f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.273972f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.405708f) {
                if (feat_array[1] <= 0.274075f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 169
    // ----------------------------------------
        if (feat_array[1] <= 0.258898f) {
            if (feat_array[2] <= 0.403172f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[2] <= 0.415284f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 170
    // ----------------------------------------
        if (feat_array[2] <= 0.401050f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.368704f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 171
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.287667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 172
    // ----------------------------------------
        if (feat_array[1] <= 0.259704f) {
            if (feat_array[1] <= 0.189105f) {
                if (feat_array[1] <= 0.164913f) {
                    if (feat_array[0] <= 0.405783f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.409726f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.220846f) {
                    if (feat_array[1] <= 0.189365f) {
                        if (feat_array[0] <= 0.407047f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[0] <= 0.407823f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.385094f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[2] <= 0.398559f) {
                if (feat_array[0] <= 0.381256f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369593f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 173
    // ----------------------------------------
        if (feat_array[2] <= 0.397476f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.410032f) {
                if (feat_array[0] <= 0.381711f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 174
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.287667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 175
    // ----------------------------------------
        if (feat_array[2] <= 0.393407f) {
            if (feat_array[0] <= 0.398156f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399110f) {
                if (feat_array[0] <= 0.409185f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 176
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409807f) {
                if (feat_array[1] <= 0.294386f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 177
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[2] <= 0.388553f) {
                if (feat_array[0] <= 0.398508f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[1] <= 0.274379f) {
                    if (feat_array[0] <= 0.379350f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 178
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272822f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 179
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 180
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.265225f) {
                if (feat_array[0] <= 0.386681f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.272363f) {
                    if (feat_array[0] <= 0.393915f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 181
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 182
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[2] <= 0.384145f) {
                if (feat_array[2] <= 0.370092f) {
                    if (feat_array[0] <= 0.398156f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.370140f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.595891f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[2] <= 0.384234f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[1] <= 0.287623f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[0] <= 0.381711f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 183
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[1] <= 0.201680f) {
                if (feat_array[1] <= 0.177054f) {
                    if (feat_array[2] <= 0.381269f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.177102f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.410656f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[0] <= 0.388081f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.369986f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 184
    // ----------------------------------------
        if (feat_array[1] <= 0.260953f) {
            if (feat_array[2] <= 0.403889f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.401050f) {
                if (feat_array[2] <= 0.371546f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[0] <= 0.381225f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.369593f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 185
    // ----------------------------------------
        if (feat_array[0] <= 0.372724f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 186
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[1] <= 0.286873f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 187
    // ----------------------------------------
        if (feat_array[0] <= 0.373115f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 188
    // ----------------------------------------
        if (feat_array[1] <= 0.261288f) {
            if (feat_array[2] <= 0.403749f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.264570f) {
                if (feat_array[1] <= 0.262937f) {
                    if (feat_array[0] <= 0.385445f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.263549f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[1] <= 0.264172f) {
                            arc_fault_votes += 1;
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    }
                }
            } else {
                if (feat_array[1] <= 0.274569f) {
                    if (feat_array[0] <= 0.380632f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 189
    // ----------------------------------------
        if (feat_array[1] <= 0.261978f) {
            if (feat_array[0] <= 0.393820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.400586f) {
                if (feat_array[2] <= 0.371331f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[0] <= 0.395794f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[1] <= 0.274509f) {
                    if (feat_array[1] <= 0.274379f) {
                        arc_fault_votes += 1;
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 190
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 191
    // ----------------------------------------
        if (feat_array[0] <= 0.369937f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 192
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372908f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 193
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 194
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 195
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 196
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 197
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[1] <= 0.201680f) {
                if (feat_array[2] <= 0.395591f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.396657f) {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.400586f) {
                    if (feat_array[1] <= 0.350070f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 198
    // ----------------------------------------
        if (feat_array[1] <= 0.263085f) {
            if (feat_array[1] <= 0.189105f) {
                if (feat_array[1] <= 0.171765f) {
                    if (feat_array[2] <= 0.385987f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.171783f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.184908f) {
                            if (feat_array[1] <= 0.184777f) {
                                if (feat_array[1] <= 0.184259f) {
                                    if (feat_array[2] <= 0.391152f) {
                                        // arc_fault_votes += 0; (Normal Vote)
                                    } else {
                                        arc_fault_votes += 1;
                                    }
                                } else {
                                    if (feat_array[0] <= 0.421720f) {
                                        // arc_fault_votes += 0; (Normal Vote)
                                    } else {
                                        arc_fault_votes += 1;
                                    }
                                }
                            } else {
                                if (feat_array[0] <= 0.413022f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            }
                        } else {
                            if (feat_array[2] <= 0.440041f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                }
            } else {
                if (feat_array[0] <= 0.388081f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.372724f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 199
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 200
    // ----------------------------------------
        if (feat_array[2] <= 0.399836f) {
            if (feat_array[2] <= 0.384145f) {
                if (feat_array[2] <= 0.374641f) {
                    if (feat_array[2] <= 0.353718f) {
                        if (feat_array[0] <= 0.488341f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[1] <= 0.288741f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[0] <= 0.397704f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.384234f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[0] <= 0.465256f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 201
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 202
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.402893f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 203
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 204
    // ----------------------------------------
        if (feat_array[2] <= 0.395036f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.405884f) {
                if (feat_array[1] <= 0.274075f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 205
    // ----------------------------------------
        if (feat_array[0] <= 0.373115f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 206
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 207
    // ----------------------------------------
        if (feat_array[2] <= 0.399836f) {
            if (feat_array[1] <= 0.287667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 208
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 209
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[2] <= 0.412664f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.397716f) {
                if (feat_array[1] <= 0.277820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369593f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 210
    // ----------------------------------------
        if (feat_array[0] <= 0.370025f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 211
    // ----------------------------------------
        if (feat_array[1] <= 0.262394f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.266505f) {
                if (feat_array[2] <= 0.446536f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.370244f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 212
    // ----------------------------------------
        if (feat_array[1] <= 0.264570f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[1] <= 0.274379f) {
                    if (feat_array[0] <= 0.380632f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 213
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 214
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[2] <= 0.387289f) {
                if (feat_array[2] <= 0.370092f) {
                    if (feat_array[2] <= 0.353555f) {
                        if (feat_array[2] <= 0.265116f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            if (feat_array[0] <= 0.488341f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    } else {
                        if (feat_array[0] <= 0.397846f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[2] <= 0.370156f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[1] <= 0.307545f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[0] <= 0.381997f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.274619f) {
                if (feat_array[2] <= 0.411312f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 215
    // ----------------------------------------
        if (feat_array[1] <= 0.263093f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.384343f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 216
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[2] <= 0.388741f) {
                if (feat_array[0] <= 0.398513f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.389542f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[2] <= 0.393407f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        if (feat_array[1] <= 0.283606f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 217
    // ----------------------------------------
        if (feat_array[1] <= 0.259704f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.399110f) {
                if (feat_array[2] <= 0.371546f) {
                    arc_fault_votes += 1;
                } else {
                    if (feat_array[0] <= 0.381256f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[2] <= 0.409521f) {
                    if (feat_array[0] <= 0.381711f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 218
    // ----------------------------------------
        if (feat_array[1] <= 0.262008f) {
            if (feat_array[1] <= 0.201642f) {
                if (feat_array[1] <= 0.179315f) {
                    if (feat_array[0] <= 0.405592f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.179365f) {
                        arc_fault_votes += 1;
                    } else {
                        if (feat_array[0] <= 0.409347f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            } else {
                if (feat_array[1] <= 0.224577f) {
                    if (feat_array[1] <= 0.201970f) {
                        if (feat_array[0] <= 0.410514f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[2] <= 0.409905f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                } else {
                    if (feat_array[1] <= 0.254006f) {
                        if (feat_array[0] <= 0.398638f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[0] <= 0.384029f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    }
                }
            }
        } else {
            if (feat_array[1] <= 0.272407f) {
                if (feat_array[1] <= 0.271690f) {
                    if (feat_array[2] <= 0.408467f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[2] <= 0.409780f) {
                    if (feat_array[2] <= 0.408749f) {
                        arc_fault_votes += 1;
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 219
    // ----------------------------------------
        if (feat_array[1] <= 0.256070f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.264570f) {
                if (feat_array[2] <= 0.412664f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.274509f) {
                    if (feat_array[1] <= 0.274379f) {
                        if (feat_array[1] <= 0.271599f) {
                            if (feat_array[1] <= 0.265225f) {
                                if (feat_array[2] <= 0.467315f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            } else {
                                if (feat_array[0] <= 0.370532f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            }
                        } else {
                            if (feat_array[0] <= 0.384343f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 220
    // ----------------------------------------
        if (feat_array[1] <= 0.260281f) {
            if (feat_array[2] <= 0.403307f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[1] <= 0.274379f) {
                    if (feat_array[1] <= 0.264570f) {
                        if (feat_array[2] <= 0.412664f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[1] <= 0.271529f) {
                            if (feat_array[0] <= 0.392744f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            if (feat_array[0] <= 0.384662f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 221
    // ----------------------------------------
        if (feat_array[0] <= 0.370377f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 222
    // ----------------------------------------
        if (feat_array[0] <= 0.370954f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 223
    // ----------------------------------------
        if (feat_array[2] <= 0.400938f) {
            if (feat_array[0] <= 0.382656f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372405f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 224
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[0] <= 0.398508f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409521f) {
                if (feat_array[2] <= 0.408749f) {
                    if (feat_array[1] <= 0.283538f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 225
    // ----------------------------------------
        if (feat_array[1] <= 0.262268f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[0] <= 0.380239f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 226
    // ----------------------------------------
        if (feat_array[2] <= 0.398318f) {
            if (feat_array[0] <= 0.398156f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.405884f) {
                if (feat_array[0] <= 0.381711f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 227
    // ----------------------------------------
        if (feat_array[2] <= 0.393271f) {
            if (feat_array[0] <= 0.398513f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274552f) {
                if (feat_array[2] <= 0.411312f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 228
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.272783f) {
                if (feat_array[1] <= 0.271690f) {
                    arc_fault_votes += 1;
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 229
    // ----------------------------------------
        if (feat_array[0] <= 0.370602f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 230
    // ----------------------------------------
        if (feat_array[1] <= 0.262226f) {
            if (feat_array[1] <= 0.201039f) {
                if (feat_array[1] <= 0.171765f) {
                    if (feat_array[2] <= 0.388986f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.395591f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            } else {
                if (feat_array[0] <= 0.385753f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[2] <= 0.409780f) {
                if (feat_array[0] <= 0.381711f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 231
    // ----------------------------------------
        if (feat_array[1] <= 0.262316f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.401050f) {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.372331f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 232
    // ----------------------------------------
        if (feat_array[1] <= 0.261978f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.264570f) {
                if (feat_array[0] <= 0.386681f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[0] <= 0.369986f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 233
    // ----------------------------------------
        if (feat_array[1] <= 0.265225f) {
            if (feat_array[1] <= 0.201880f) {
                if (feat_array[2] <= 0.377861f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.225567f) {
                    if (feat_array[0] <= 0.408127f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.407072f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        } else {
            if (feat_array[2] <= 0.386961f) {
                if (feat_array[2] <= 0.378878f) {
                    if (feat_array[0] <= 0.388016f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    // arc_fault_votes += 0; (Normal Vote)
                }
            } else {
                if (feat_array[0] <= 0.369986f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 234
    // ----------------------------------------
        if (feat_array[1] <= 0.261985f) {
            if (feat_array[0] <= 0.393820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.401198f) {
                if (feat_array[1] <= 0.277776f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 235
    // ----------------------------------------
        if (feat_array[2] <= 0.393013f) {
            if (feat_array[1] <= 0.277026f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.380313f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 236
    // ----------------------------------------
        if (feat_array[1] <= 0.262755f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.398559f) {
                if (feat_array[0] <= 0.382264f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.409521f) {
                    if (feat_array[1] <= 0.274935f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 237
    // ----------------------------------------
        if (feat_array[1] <= 0.253441f) {
            if (feat_array[2] <= 0.418433f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.262482f) {
                if (feat_array[0] <= 0.383320f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.392796f) {
                    if (feat_array[1] <= 0.336729f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[0] <= 0.370244f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        }

    // ----------------------------------------
    // TREE 238
    // ----------------------------------------
        if (feat_array[1] <= 0.261288f) {
            if (feat_array[1] <= 0.192061f) {
                if (feat_array[0] <= 0.409917f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[1] <= 0.221199f) {
                    if (feat_array[2] <= 0.407219f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[1] <= 0.222569f) {
                        if (feat_array[2] <= 0.427697f) {
                            // arc_fault_votes += 0; (Normal Vote)
                        } else {
                            arc_fault_votes += 1;
                        }
                    } else {
                        if (feat_array[1] <= 0.251967f) {
                            if (feat_array[1] <= 0.251374f) {
                                if (feat_array[0] <= 0.398841f) {
                                    // arc_fault_votes += 0; (Normal Vote)
                                } else {
                                    arc_fault_votes += 1;
                                }
                            } else {
                                // arc_fault_votes += 0; (Normal Vote)
                            }
                        } else {
                            if (feat_array[0] <= 0.383320f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        }
                    }
                }
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 239
    // ----------------------------------------
        if (feat_array[1] <= 0.262316f) {
            if (feat_array[1] <= 0.201139f) {
                if (feat_array[2] <= 0.377861f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.410091f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[1] <= 0.264570f) {
                if (feat_array[0] <= 0.412583f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.396657f) {
                    if (feat_array[0] <= 0.382264f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    if (feat_array[2] <= 0.409521f) {
                        if (feat_array[2] <= 0.408648f) {
                            if (feat_array[0] <= 0.385485f) {
                                // arc_fault_votes += 0; (Normal Vote)
                            } else {
                                arc_fault_votes += 1;
                            }
                        } else {
                            // arc_fault_votes += 0; (Normal Vote)
                        }
                    } else {
                        arc_fault_votes += 1;
                    }
                }
            }
        }

    // ----------------------------------------
    // TREE 240
    // ----------------------------------------
        if (feat_array[2] <= 0.396657f) {
            if (feat_array[1] <= 0.287667f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 241
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[0] <= 0.398161f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370244f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 242
    // ----------------------------------------
        if (feat_array[0] <= 0.369986f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 243
    // ----------------------------------------
        if (feat_array[0] <= 0.370602f) {
            // arc_fault_votes += 0; (Normal Vote)
        } else {
            arc_fault_votes += 1;
        }

    // ----------------------------------------
    // TREE 244
    // ----------------------------------------
        if (feat_array[2] <= 0.398559f) {
            if (feat_array[2] <= 0.369689f) {
                if (feat_array[2] <= 0.353759f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    if (feat_array[2] <= 0.353797f) {
                        arc_fault_votes += 1;
                    } else {
                        // arc_fault_votes += 0; (Normal Vote)
                    }
                }
            } else {
                if (feat_array[1] <= 0.277820f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            }
        } else {
            if (feat_array[0] <= 0.372405f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 245
    // ----------------------------------------
        if (feat_array[1] <= 0.259389f) {
            if (feat_array[0] <= 0.385753f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.266455f) {
                if (feat_array[0] <= 0.386681f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                if (feat_array[2] <= 0.409521f) {
                    if (feat_array[1] <= 0.274935f) {
                        // arc_fault_votes += 0; (Normal Vote)
                    } else {
                        arc_fault_votes += 1;
                    }
                } else {
                    arc_fault_votes += 1;
                }
            }
        }

    // ----------------------------------------
    // TREE 246
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.294650f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.370170f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 247
    // ----------------------------------------
        if (feat_array[2] <= 0.399110f) {
            if (feat_array[0] <= 0.382264f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.369593f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 248
    // ----------------------------------------
        if (feat_array[1] <= 0.262129f) {
            if (feat_array[2] <= 0.406323f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[2] <= 0.409780f) {
                if (feat_array[1] <= 0.274935f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 249
    // ----------------------------------------
        if (feat_array[2] <= 0.400586f) {
            if (feat_array[1] <= 0.277820f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[1] <= 0.274509f) {
                if (feat_array[0] <= 0.380239f) {
                    // arc_fault_votes += 0; (Normal Vote)
                } else {
                    arc_fault_votes += 1;
                }
            } else {
                arc_fault_votes += 1;
            }
        }

    // ----------------------------------------
    // TREE 250
    // ----------------------------------------
        if (feat_array[1] <= 0.261978f) {
            if (feat_array[2] <= 0.406462f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        } else {
            if (feat_array[0] <= 0.372724f) {
                // arc_fault_votes += 0; (Normal Vote)
            } else {
                arc_fault_votes += 1;
            }
        }

    // ============================================================================
    // ENSEMBLE VOTING LOGIC
    // ============================================================================
    if (arc_fault_votes > 125) {
        return 1; // Arc Fault Detected
    } else {
        return 0; // Normal Operation
    }
